#include "manager.h"
#include "parser.h"
#include "commands_container.h"
#include <list>

Manager::Manager(ICli *cli, Data *dnaData): m_cli(cli), m_dnaData(dnaData)
{
    CommandsContainer::init_map_command(m_dnaData);
}

void Manager::run()
{
    std::string input = m_cli->input();
//    Parser parser;
    std::vector<std::string> parse = Parser::parser(input);
    ICommand* command = CommandsContainer::get_command(parse[0]);
//    ICommand* command = m_parser->parser(m_cli->input()) ;

    std::string output = command->action(parse);
    m_cli->output(output);
}
