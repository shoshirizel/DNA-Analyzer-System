
#include "commands_container.h"
#include <fstream>
#include <string>
#include <iostream>
#include "load.h"

std::map<std::string,ICommand*> CommandsContainer::commands;

void CommandsContainer::init_map_command(Data* dna_data)
{
	commands["load"] = new Load(dna_data);
}


ICommand* CommandsContainer::get_command(std::string str)
{
	return commands[str];
}


