//
// Created by shoshi on 8/19/20.
//

#ifndef CODE_FACTORY_H
#define CODE_FACTORY_H


class factory {

};


#endif //CODE_FACTORY_H
